#include <iostream>
#include <stdio.h>

using namespace std;

int main()
{
    char texto[100];
    gets(texto);
    cout << texto << endl;
    return 0;
}
